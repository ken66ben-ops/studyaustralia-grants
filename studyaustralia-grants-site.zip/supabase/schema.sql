-- StudyAustralia Grants database. Run once in Supabase → SQL Editor → New query → Run.

create table if not exists posts (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  body text not null,
  image_url text,
  published boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists subscribers (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  email text not null unique,
  country text,
  level text,
  field text,
  consent boolean not null,
  created_at timestamptz not null default now()
);

-- Anonymous visit and click counts. No IP addresses or names are stored.
create table if not exists events (
  id bigserial primary key,
  type text not null check (type in ('view', 'click')),
  path text,
  scholarship text,
  country text,
  referrer text,
  created_at timestamptz not null default now()
);
create index if not exists events_created_at_idx on events (created_at);

-- Lock the tables: the public cannot read or write them directly.
-- The website's server code uses the service role key, which bypasses these locks.
alter table posts enable row level security;
alter table subscribers enable row level security;
alter table events enable row level security;

-- Public bucket for pictures in news posts.
insert into storage.buckets (id, name, public)
values ('post-images', 'post-images', true)
on conflict (id) do nothing;

-- Summary numbers for the admin dashboard.
create or replace function site_stats(days int default 30)
returns json
language sql
stable
as $$
  with recent as (
    select * from events where created_at >= now() - make_interval(days => days)
  )
  select json_build_object(
    'views_today', (select count(*) from events where type = 'view' and created_at >= date_trunc('day', now())),
    'views_7',     (select count(*) from events where type = 'view' and created_at >= now() - interval '7 days'),
    'views',       (select count(*) from recent where type = 'view'),
    'clicks',      (select count(*) from recent where type = 'click'),
    'daily', (select coalesce(json_agg(d order by d.day), '[]'::json) from (
        select created_at::date as day,
               count(*) filter (where type = 'view')  as views,
               count(*) filter (where type = 'click') as clicks
        from recent group by 1) d),
    'countries', (select coalesce(json_agg(c), '[]'::json) from (
        select coalesce(country, 'Unknown') as name, count(*) as n
        from recent where type = 'view' group by 1 order by 2 desc limit 15) c),
    'referrers', (select coalesce(json_agg(r), '[]'::json) from (
        select coalesce(referrer, 'Direct / unknown') as name, count(*) as n
        from recent where type = 'view' group by 1 order by 2 desc limit 10) r),
    'pages', (select coalesce(json_agg(p), '[]'::json) from (
        select path as name, count(*) as n
        from recent where type = 'view' group by 1 order by 2 desc limit 10) p),
    'clicks_by_scholarship', (select coalesce(json_agg(k), '[]'::json) from (
        select scholarship as name, count(*) as n
        from recent where type = 'click' group by 1 order by 2 desc limit 30) k)
  );
$$;
revoke execute on function site_stats(int) from public, anon, authenticated;

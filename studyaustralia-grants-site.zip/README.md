# StudyAustralia Grants

An independent site listing genuine, currently open scholarships at Australian universities. Not affiliated with any university or government.

## How it works

- Next.js site (App Router) hosted on Vercel, with a Supabase database for news posts, pictures, visit counts and alert sign-ups.
- `data/scholarships.json` holds the scholarship list. It is the only file the weekly update changes.
- `/admin` is the admin dashboard (password login): post updates with pictures, see visits, countries and clicks on each scholarship, and download alert subscribers.
- `captions/YYYY-MM-DD.md` holds that week's ready-to-post Facebook captions.
- Vercel publishes the site automatically whenever `main` changes.

## Weekly update

Every Monday a scheduled task checks official university and government pages, then opens a pull request named `Weekly scholarship update – <date>`. Review it, then click **Merge**, and the site updates within a minute.

## data/scholarships.json fields

| Field | Meaning |
|---|---|
| `uni` | University or provider name |
| `name` | Scholarship name as the provider writes it |
| `level` / `level2` | `PhD / Research`, `Master by Coursework` or `Undergraduate` |
| `who` | `both`, `intl` (international only) or `dom` (domestic only) |
| `value` | Amount in AUD, as stated on the official page |
| `field` | Discipline, or `All disciplines` |
| `opens` / `closes` | Dates as `YYYY-MM-DD`, taken from the official page |
| `note` | Key eligibility points |
| `url` | Official university or government page (never a third-party blog) |

`verified` at the top is the date the list was last checked.

## Setup (once)

1. Supabase: create a free project, open SQL Editor, paste `supabase/schema.sql` and click Run.
2. Vercel: import this GitHub repo, then add these Environment Variables (see `.env.example`): `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`, `ADMIN_PASSWORD`, `SESSION_SECRET`. Redeploy.
3. Visit `/admin` and sign in with your admin password.

## What visitors data is collected

Anonymous page views (page, referring site, country, time) and clicks on "View official page". No IP addresses or names. Names and emails are stored only when someone signs up for alerts and ticks the consent box. See `/privacy`.

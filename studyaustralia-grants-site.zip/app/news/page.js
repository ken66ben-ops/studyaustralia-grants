import { listPosts } from "@/lib/posts";
import PostCard from "../components/PostCard";

export const revalidate = 60;
export const metadata = { title: "News – StudyAustralia Grants" };

export default async function News() {
  const posts = await listPosts({ limit: 100 });
  return (
    <main>
      <section>
        <div className="wrap">
          <div className="section-head"><div><h2>News and updates</h2><p>Scholarship news, application tips and deadline reminders.</p></div></div>
          {posts.length === 0 ? (
            <div className="empty">No updates yet. Check back soon.</div>
          ) : (
            <div className="news-grid">{posts.map((p) => <PostCard key={p.id} p={p} />)}</div>
          )}
        </div>
      </section>
    </main>
  );
}

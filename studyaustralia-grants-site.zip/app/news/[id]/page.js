import Link from "next/link";
import { notFound } from "next/navigation";
import { getPost, fmtPostDate } from "@/lib/posts";

export const revalidate = 60;

export async function generateMetadata({ params }) {
  const p = await getPost(params.id);
  return { title: p ? `${p.title} – StudyAustralia Grants` : "Update not found" };
}

export default async function PostPage({ params }) {
  const p = await getPost(params.id);
  if (!p) notFound();
  return (
    <main className="article">
      <Link className="back" href="/news">← All updates</Link>
      <time className="muted" dateTime={p.created_at}>{fmtPostDate(p.created_at)}</time>
      <h1>{p.title}</h1>
      {p.image_url && <img src={p.image_url} alt="" />}
      <div className="body">{p.body}</div>
    </main>
  );
}

import Link from "next/link";
import { db } from "@/lib/supabase";
import { listPosts, fmtPostDate } from "@/lib/posts";
import { PostForm, PostActions, RemoveSubscriber } from "./AdminClient";

export const dynamic = "force-dynamic";
export const metadata = { title: "Admin – StudyAustralia Grants", robots: { index: false } };

function TopList({ title, rows, empty }) {
  const max = Math.max(1, ...rows.map((r) => r.n));
  return (
    <div className="panel">
      <h3>{title}</h3>
      {rows.length === 0 ? <p className="muted">{empty}</p> : (
        <table className="tbl"><tbody>
          {rows.map((r) => (
            <tr key={r.name}>
              <td style={{ width: "55%" }}>{r.name}</td>
              <td style={{ width: "35%" }}><div className="bar" style={{ width: `${(r.n / max) * 100}%` }} /></td>
              <td style={{ textAlign: "right" }}>{r.n}</td>
            </tr>
          ))}
        </tbody></table>
      )}
    </div>
  );
}

export default async function Admin() {
  const s = db();
  if (!s) {
    return (
      <main className="admin">
        <div className="panel">
          <h3>Database not connected yet</h3>
          <p className="meta">Add SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY in Vercel → Settings → Environment Variables, then redeploy.</p>
        </div>
      </main>
    );
  }

  const [statsRes, subsRes, subCount, posts] = await Promise.all([
    s.rpc("site_stats", { days: 30 }),
    s.from("subscribers").select("*").order("created_at", { ascending: false }).limit(100),
    s.from("subscribers").select("id", { count: "exact", head: true }),
    listPosts({ limit: 100, includeDrafts: true }),
  ]);
  const st = statsRes.data || { views_today: 0, views_7: 0, views: 0, clicks: 0, daily: [], countries: [], referrers: [], pages: [], clicks_by_scholarship: [] };
  const subs = subsRes.data || [];
  const maxDay = Math.max(1, ...st.daily.map((d) => d.views));

  return (
    <main className="admin">
      <div className="admin-top">
        <h2>Admin dashboard</h2>
        <div style={{ display: "flex", gap: 8 }}>
          <Link className="btn ghost" href="/">View site</Link>
          <form method="post" action="/api/admin/logout"><button className="btn ghost">Sign out</button></form>
        </div>
      </div>
      {statsRes.error && <p className="msg err">Stats unavailable: {statsRes.error.message}. Did you run supabase/schema.sql?</p>}

      <div className="kpis">
        <div className="kpi"><b>{st.views_today}</b><span>visits today</span></div>
        <div className="kpi"><b>{st.views_7}</b><span>visits, last 7 days</span></div>
        <div className="kpi"><b>{st.views}</b><span>visits, last 30 days</span></div>
        <div className="kpi"><b>{st.clicks}</b><span>clicks to official pages (30 days)</span></div>
        <div className="kpi"><b>{subCount.count ?? 0}</b><span>alert subscribers</span></div>
      </div>

      <div className="panel">
        <h3>Daily visits, last 30 days</h3>
        {st.daily.length === 0 ? <p className="muted">No visits recorded yet.</p> : (
          <div className="table-wrap"><table className="tbl"><thead><tr><th>Day</th><th>Visits</th><th></th><th>Clicks</th></tr></thead><tbody>
            {[...st.daily].reverse().map((d) => (
              <tr key={d.day}><td>{d.day}</td><td>{d.views}</td><td style={{ width: "50%" }}><div className="bar" style={{ width: `${(d.views / maxDay) * 100}%` }} /></td><td>{d.clicks}</td></tr>
            ))}
          </tbody></table></div>
        )}
      </div>

      <TopList title="Most clicked scholarships (people heading to apply)" rows={st.clicks_by_scholarship} empty="No clicks yet." />
      <div className="two">
        <TopList title="Visitors by country" rows={st.countries} empty="No visits yet." />
        <TopList title="Where visitors came from" rows={st.referrers} empty="No visits yet." />
      </div>

      <div className="panel">
        <h3>Post an update</h3>
        <PostForm />
      </div>

      <div className="panel">
        <h3>Your updates</h3>
        {posts.length === 0 ? <p className="muted">No updates yet.</p> : (
          <div className="table-wrap"><table className="tbl"><thead><tr><th>Date</th><th>Title</th><th>Status</th><th></th></tr></thead><tbody>
            {posts.map((p) => (
              <tr key={p.id}>
                <td>{fmtPostDate(p.created_at)}</td>
                <td>{p.published ? <Link href={`/news/${p.id}`}>{p.title}</Link> : p.title}{p.image_url ? " 🖼" : ""}</td>
                <td>{p.published ? "Live" : "Hidden"}</td>
                <td><PostActions id={p.id} published={p.published} /></td>
              </tr>
            ))}
          </tbody></table></div>
        )}
      </div>

      <div className="panel">
        <div className="admin-top" style={{ marginBottom: 10 }}>
          <h3>Alert subscribers</h3>
          <a className="btn ghost" href="/api/admin/subscribers">Download all (CSV)</a>
        </div>
        {subs.length === 0 ? <p className="muted">No sign-ups yet.</p> : (
          <div className="table-wrap"><table className="tbl"><thead><tr><th>Joined</th><th>Name</th><th>Email</th><th>Country</th><th>Level</th><th>Field</th><th></th></tr></thead><tbody>
            {subs.map((r) => (
              <tr key={r.id}>
                <td>{fmtPostDate(r.created_at)}</td><td>{r.name}</td><td>{r.email}</td><td>{r.country}</td><td>{r.level}</td><td>{r.field}</td>
                <td><RemoveSubscriber id={r.id} /></td>
              </tr>
            ))}
          </tbody></table></div>
        )}
        {(subCount.count ?? 0) > 100 && <p className="muted">Showing the latest 100. Download the CSV for everyone.</p>}
      </div>
    </main>
  );
}

"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

export function PostForm() {
  const router = useRouter();
  const [state, setState] = useState({ busy: false, ok: "", err: "" });
  const [preview, setPreview] = useState(null);

  async function submit(e) {
    e.preventDefault();
    const form = e.currentTarget;
    const fd = new FormData(form);
    fd.set("published", form.published.checked ? "true" : "false");
    setState({ busy: true, ok: "", err: "" });
    const r = await fetch("/api/admin/posts", { method: "POST", body: fd });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) return setState({ busy: false, ok: "", err: j.error || "Couldn't publish." });
    form.reset(); setPreview(null);
    setState({ busy: false, ok: fd.get("published") === "true" ? "Published. It's live on the site now." : "Saved as hidden.", err: "" });
    router.refresh();
  }

  return (
    <form className="form" onSubmit={submit}>
      <label>Title<input name="title" required maxLength={200} placeholder="e.g. UQ international PhD round closes Monday" /></label>
      <label>Text<textarea name="body" required maxLength={20000} placeholder="Write your update. Line breaks are kept." /></label>
      <label>Picture (optional, JPG/PNG/WebP, under 4 MB)
        <input name="image" type="file" accept="image/jpeg,image/png,image/webp,image/gif"
          onChange={(e) => { const f = e.target.files?.[0]; setPreview(f ? URL.createObjectURL(f) : null); }} />
      </label>
      {preview && <img src={preview} alt="Selected picture preview" style={{ maxWidth: 320, borderRadius: 10 }} />}
      <label className="check"><input type="checkbox" name="published" defaultChecked /><span>Publish on the site now (untick to save it hidden)</span></label>
      <div><button className="btn" disabled={state.busy}>{state.busy ? "Publishing…" : "Publish update"}</button></div>
      {state.ok && <p className="msg ok" role="status">{state.ok}</p>}
      {state.err && <p className="msg err" role="alert">{state.err}</p>}
    </form>
  );
}

export function PostActions({ id, published }) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [confirming, setConfirming] = useState(false);

  async function call(method, body) {
    setBusy(true);
    await fetch(`/api/admin/posts/${id}`, { method, headers: { "content-type": "application/json" }, body: body ? JSON.stringify(body) : undefined });
    setBusy(false); setConfirming(false);
    router.refresh();
  }

  return (
    <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
      <button className="btn ghost" disabled={busy} onClick={() => call("PATCH", { published: !published })}>{published ? "Hide" : "Show"}</button>
      {confirming ? (
        <>
          <button className="btn danger" disabled={busy} onClick={() => call("DELETE")}>Yes, delete</button>
          <button className="btn ghost" disabled={busy} onClick={() => setConfirming(false)}>Cancel</button>
        </>
      ) : (
        <button className="btn ghost" disabled={busy} onClick={() => setConfirming(true)}>Delete</button>
      )}
    </div>
  );
}

export function RemoveSubscriber({ id }) {
  const router = useRouter();
  const [confirming, setConfirming] = useState(false);
  async function remove() {
    await fetch("/api/admin/subscribers", { method: "DELETE", headers: { "content-type": "application/json" }, body: JSON.stringify({ id }) });
    router.refresh();
  }
  return confirming ? (
    <span style={{ display: "inline-flex", gap: 6 }}>
      <button className="btn danger" onClick={remove}>Remove</button>
      <button className="btn ghost" onClick={() => setConfirming(false)}>Cancel</button>
    </span>
  ) : (
    <button className="btn ghost" onClick={() => setConfirming(true)}>Remove</button>
  );
}

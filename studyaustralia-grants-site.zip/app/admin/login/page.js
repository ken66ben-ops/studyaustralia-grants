export const metadata = { title: "Admin sign in – StudyAustralia Grants", robots: { index: false } };

export default function Login({ searchParams }) {
  return (
    <main className="login">
      <div className="panel">
        <h3>Admin sign in</h3>
        <form className="form" method="post" action="/api/admin/login" style={{ marginTop: 12 }}>
          <label>Password<input type="password" name="password" required autoFocus autoComplete="current-password" /></label>
          {searchParams?.error && <p className="msg err" role="alert">Wrong password. Try again.</p>}
          <button className="btn">Sign in</button>
        </form>
      </div>
    </main>
  );
}

export const metadata = { title: "Privacy – StudyAustralia Grants" };

export default function Privacy() {
  return (
    <main className="article">
      <h1>Privacy</h1>
      <div className="body">{`StudyAustralia Grants is an independent information website. This page explains what we collect and why.

Visit statistics
When you open a page we record the page address, the website that sent you (if any), your approximate country (worked out by our hosting provider), and the date and time. When you click "View official page" we record which scholarship you clicked. We do not store your IP address, name or any identifier that links these records to you. We use these counts only to see which scholarships people find useful.

Deadline alerts
If you sign up for alerts, we store the name, email, country, study level and field you give us, so we can email you relevant scholarships. We do not sell or share these details. To unsubscribe or have your details deleted, reply to any alert email or contact the site owner, and we will remove you.

What we never ask for
We never ask for passports, bank details, payment or application fees. If anyone claiming to be us asks for these, it is a scam.

Applications
We do not take or see scholarship applications. You apply on each university's own website, under that university's privacy policy.`}</div>
    </main>
  );
}

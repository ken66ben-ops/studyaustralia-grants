import Link from "next/link";
import { getScholarships, status, fmtDate } from "@/lib/scholarships";
import { listPosts } from "@/lib/posts";
import ScholarshipBrowser from "./components/ScholarshipBrowser";
import SubscribeForm from "./components/SubscribeForm";
import PostCard from "./components/PostCard";

export const revalidate = 60;

export default async function Home() {
  const { verified, list } = getScholarships();
  const openCount = list.filter((x) => status(x).k === "open").length;
  const posts = await listPosts({ limit: 3 });

  return (
    <>
      <header className="hero" id="top">
        <div className="wrap">
          <span className="eyebrow">Independent scholarship guide</span>
          <h1>Funded study in Australia, verified at the source</h1>
          <p>
            Real scholarships at Edith Cowan University and other Australian universities: research stipends,
            tuition-fee reductions and government awards. Every listing links straight to the official university page
            where you apply.
          </p>
          <div className="stats">
            <div className="stat"><b>{list.length}</b><span>scholarships listed</span></div>
            <div className="stat"><b>{openCount}</b><span>open right now</span></div>
            <div className="stat"><b>A$37.5k–41k</b><span>typical PhD stipend / year</span></div>
          </div>
        </div>
      </header>

      <div className="wrap">
        <div className="notice" role="note">
          <strong>StudyAustralia Grants is independent and is not affiliated with any university or government.</strong>{" "}
          We do not award scholarships, take applications or charge fees. Apply only through the official links below,
          and never pay anyone who promises a guaranteed scholarship. Details were checked against official pages on{" "}
          <b>{fmtDate(verified)}</b>; always confirm on the university&apos;s site before applying.
        </div>
      </div>

      <main>
        {posts.length > 0 && (
          <section id="news" style={{ paddingBottom: 0 }}>
            <div className="wrap">
              <div className="section-head">
                <div><h2>Latest updates</h2><p>News, tips and deadline reminders.</p></div>
                <Link href="/news">All updates →</Link>
              </div>
              <div className="news-grid">{posts.map((p) => <PostCard key={p.id} p={p} />)}</div>
            </div>
          </section>
        )}

        <section id="scholarships">
          <div className="wrap">
            <div className="section-head">
              <div><h2>Scholarship listings</h2><p>Filter by university, study level, who can apply and status.</p></div>
            </div>
            <ScholarshipBrowser list={list} />
          </div>
        </section>

        <section id="alerts" style={{ paddingTop: 0 }}>
          <div className="wrap">
            <div className="panel">
              <h3>Get deadline alerts</h3>
              <p className="meta" style={{ marginBottom: 14 }}>
                Tell us what you want to study and we&apos;ll email you when matching scholarships open or are about to close.
              </p>
              <SubscribeForm />
            </div>
          </div>
        </section>

        <section id="stipends" style={{ paddingTop: 0 }}>
          <div className="wrap two">
            <div className="panel">
              <h3>PhD stipend rates at a glance</h3>
              <table className="rates">
                <thead><tr><th>University</th><th>Stipend / year</th><th>Rate year</th></tr></thead>
                <tbody>
                  <tr><td>Monash</td><td>A$41,100</td><td>2027</td></tr>
                  <tr><td>ANU</td><td>A$40,475</td><td>2027</td></tr>
                  <tr><td>UWA</td><td>A$39,253</td><td>2027</td></tr>
                  <tr><td>UQ</td><td>A$39,220</td><td>2026</td></tr>
                  <tr><td>Wollongong</td><td>A$38,420</td><td>2027</td></tr>
                  <tr><td>Edith Cowan</td><td>A$37,500</td><td>2027 round</td></tr>
                </tbody>
              </table>
              <p className="meta" style={{ marginTop: 10 }}>
                Stipends are tax-free for full-time candidates and indexed annually. Most research scholarships also cover tuition fees.
              </p>
            </div>
            <div className="panel" id="how">
              <h3>How research scholarships work</h3>
              <ol>
                <li><b>Find a supervisor first.</b> Most PhD scholarships need written support from a principal supervisor at the university.</li>
                <li><b>Apply for admission and the scholarship together.</b> At ECU, ANU, Monash and UWA you are considered for scholarships through the research-degree application itself.</li>
                <li><b>Watch the round dates.</b> International rounds usually close months before domestic rounds.</li>
                <li><b>Coursework scholarships are often automatic.</b> ECU&apos;s 2027 international tuition reductions need no separate application; you are assessed when you apply for the course.</li>
              </ol>
            </div>
          </div>
        </section>
      </main>
    </>
  );
}

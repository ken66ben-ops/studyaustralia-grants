import { NextResponse } from "next/server";
import { db } from "@/lib/supabase";

const clip = (v, n) => (typeof v === "string" ? v.slice(0, n) : null);

export async function POST(req) {
  const s = db();
  if (!s) return new NextResponse(null, { status: 204 });
  let b;
  try { b = await req.json(); } catch { return new NextResponse(null, { status: 400 }); }
  if (b.type !== "view" && b.type !== "click") return new NextResponse(null, { status: 400 });

  // Ignore obvious bots.
  const ua = req.headers.get("user-agent") || "";
  if (/bot|crawl|spider|preview|headless/i.test(ua)) return new NextResponse(null, { status: 204 });

  let referrer = clip(b.referrer, 300);
  try { if (referrer) referrer = new URL(referrer).hostname; } catch { referrer = null; }
  const host = req.headers.get("host");
  if (referrer && host && referrer === host.split(":")[0]) referrer = null;

  await s.from("events").insert({
    type: b.type,
    path: clip(b.path, 200),
    scholarship: b.type === "click" ? clip(b.scholarship, 250) : null,
    referrer,
    country: req.headers.get("x-vercel-ip-country") || null,
  });
  return new NextResponse(null, { status: 204 });
}

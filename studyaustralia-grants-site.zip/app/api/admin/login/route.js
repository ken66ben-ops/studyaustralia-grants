import { NextResponse } from "next/server";
import { COOKIE, createSession, passwordMatches } from "@/lib/session";

export async function POST(req) {
  const form = await req.formData();
  const ok = await passwordMatches(form.get("password"));
  const url = new URL(ok ? "/admin" : "/admin/login?error=1", req.url);
  const res = NextResponse.redirect(url, 303);
  if (ok) {
    const { value, maxAge } = await createSession();
    res.cookies.set(COOKIE, value, { httpOnly: true, secure: process.env.NODE_ENV === "production", sameSite: "lax", path: "/", maxAge });
  } else {
    await new Promise((r) => setTimeout(r, 800)); // slow down password guessing
  }
  return res;
}

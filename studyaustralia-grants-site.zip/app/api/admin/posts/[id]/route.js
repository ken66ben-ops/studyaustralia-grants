import { NextResponse } from "next/server";
import { revalidatePath } from "next/cache";
import { db, IMAGE_BUCKET } from "@/lib/supabase";

function refresh(id) {
  revalidatePath("/"); revalidatePath("/news"); revalidatePath(`/news/${id}`);
}

// Show or hide a post.
export async function PATCH(req, { params }) {
  const s = db();
  if (!s) return NextResponse.json({ error: "Database not connected" }, { status: 503 });
  const { published } = await req.json();
  const { error } = await s.from("posts").update({ published: !!published }).eq("id", params.id);
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  refresh(params.id);
  return NextResponse.json({ ok: true });
}

export async function DELETE(_req, { params }) {
  const s = db();
  if (!s) return NextResponse.json({ error: "Database not connected" }, { status: 503 });
  const { data: post } = await s.from("posts").select("image_url").eq("id", params.id).maybeSingle();
  const { error } = await s.from("posts").delete().eq("id", params.id);
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  const marker = `/object/public/${IMAGE_BUCKET}/`;
  if (post?.image_url?.includes(marker)) {
    await s.storage.from(IMAGE_BUCKET).remove([post.image_url.split(marker)[1]]);
  }
  refresh(params.id);
  return NextResponse.json({ ok: true });
}

import { NextResponse } from "next/server";
import { revalidatePath } from "next/cache";
import { db, IMAGE_BUCKET } from "@/lib/supabase";

const MAX_IMAGE_BYTES = 4 * 1024 * 1024; // Vercel limits uploads to about 4.5 MB
const TYPES = { "image/jpeg": "jpg", "image/png": "png", "image/webp": "webp", "image/gif": "gif" };

export async function POST(req) {
  const s = db();
  if (!s) return NextResponse.json({ error: "Database not connected. Add the Supabase keys in Vercel." }, { status: 503 });

  const form = await req.formData();
  const title = String(form.get("title") || "").trim().slice(0, 200);
  const body = String(form.get("body") || "").trim().slice(0, 20000);
  const published = form.get("published") !== "false";
  if (!title || !body) return NextResponse.json({ error: "Title and text are required." }, { status: 400 });

  let image_url = null;
  const file = form.get("image");
  if (file && typeof file === "object" && file.size > 0) {
    const ext = TYPES[file.type];
    if (!ext) return NextResponse.json({ error: "Picture must be JPG, PNG, WebP or GIF." }, { status: 400 });
    if (file.size > MAX_IMAGE_BYTES) return NextResponse.json({ error: "Picture must be under 4 MB." }, { status: 400 });
    const path = `${new Date().toISOString().slice(0, 10)}/${crypto.randomUUID()}.${ext}`;
    const up = await s.storage.from(IMAGE_BUCKET).upload(path, Buffer.from(await file.arrayBuffer()), { contentType: file.type });
    if (up.error) return NextResponse.json({ error: "Picture upload failed: " + up.error.message }, { status: 500 });
    image_url = s.storage.from(IMAGE_BUCKET).getPublicUrl(path).data.publicUrl;
  }

  const { data, error } = await s.from("posts").insert({ title, body, image_url, published }).select().single();
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  revalidatePath("/"); revalidatePath("/news");
  return NextResponse.json({ ok: true, post: data });
}

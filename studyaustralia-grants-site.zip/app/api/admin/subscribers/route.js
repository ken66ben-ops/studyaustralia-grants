import { NextResponse } from "next/server";
import { db } from "@/lib/supabase";

const csvCell = (v) => {
  let s = v == null ? "" : String(v);
  if (/^[=+\-@]/.test(s)) s = "'" + s; // stop spreadsheet formula injection
  return `"${s.replace(/"/g, '""')}"`;
};

// Download all subscribers as a spreadsheet-friendly CSV file.
export async function GET() {
  const s = db();
  if (!s) return NextResponse.json({ error: "Database not connected" }, { status: 503 });
  const { data, error } = await s.from("subscribers").select("*").order("created_at", { ascending: false });
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  const cols = ["created_at", "name", "email", "country", "level", "field"];
  const csv = [cols.join(","), ...data.map((r) => cols.map((c) => csvCell(r[c])).join(","))].join("\n");
  return new NextResponse("﻿" + csv, {
    headers: {
      "content-type": "text/csv; charset=utf-8",
      "content-disposition": `attachment; filename="subscribers-${new Date().toISOString().slice(0, 10)}.csv"`,
    },
  });
}

// Remove a subscriber (for unsubscribe or deletion requests).
export async function DELETE(req) {
  const s = db();
  if (!s) return NextResponse.json({ error: "Database not connected" }, { status: 503 });
  const { id } = await req.json();
  const { error } = await s.from("subscribers").delete().eq("id", id);
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ ok: true });
}

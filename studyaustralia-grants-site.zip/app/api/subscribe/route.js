import { NextResponse } from "next/server";
import { db } from "@/lib/supabase";

const clean = (v, n) => (typeof v === "string" ? v.trim().slice(0, n) : "");

export async function POST(req) {
  const s = db();
  if (!s) return NextResponse.json({ error: "Sign-up isn't available yet. Please try again later." }, { status: 503 });
  let b;
  try { b = await req.json(); } catch { return NextResponse.json({ error: "Invalid request" }, { status: 400 }); }

  if (b.website) return NextResponse.json({ ok: true }); // spam trap filled in by bots

  const name = clean(b.name, 120);
  const email = clean(b.email, 200).toLowerCase();
  if (!name) return NextResponse.json({ error: "Please enter your name." }, { status: 400 });
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return NextResponse.json({ error: "Please enter a valid email." }, { status: 400 });
  if (b.consent !== true) return NextResponse.json({ error: "Please tick the consent box to sign up." }, { status: 400 });

  const { error } = await s.from("subscribers").upsert(
    { name, email, country: clean(b.country, 80) || null, level: clean(b.level, 40) || null, field: clean(b.field, 120) || null, consent: true },
    { onConflict: "email" }
  );
  if (error) {
    console.error(error.message);
    return NextResponse.json({ error: "Couldn't save your details. Please try again." }, { status: 500 });
  }
  return NextResponse.json({ ok: true });
}

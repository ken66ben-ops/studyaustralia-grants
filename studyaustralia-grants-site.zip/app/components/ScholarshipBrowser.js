"use client";
import { useMemo, useState } from "react";
import { status, fmtDate, parseDate } from "@/lib/scholarships";

const ORDER = { open: 0, upcoming: 1, closed: 2 };

export default function ScholarshipBrowser({ list }) {
  const [q, setQ] = useState("");
  const [uni, setUni] = useState("");
  const [level, setLevel] = useState("");
  const [who, setWho] = useState("");
  const [st, setSt] = useState("");

  const unis = useMemo(() => [...new Set(list.map((x) => x.uni))].sort(), [list]);

  const rows = list
    .filter((x) => {
      const s = status(x);
      if (uni && x.uni !== uni) return false;
      if (level && x.level !== level && x.level2 !== level) return false;
      if (who === "intl" && x.who === "dom") return false;
      if (who === "dom" && x.who !== "dom") return false;
      if (st && s.k !== st) return false;
      const term = q.trim().toLowerCase();
      if (term && !(x.name + " " + x.uni + " " + x.field + " " + x.note).toLowerCase().includes(term)) return false;
      return true;
    })
    .sort((a, b) => ORDER[status(a).k] - ORDER[status(b).k] || parseDate(a.closes) - parseDate(b.closes));

  return (
    <>
      <div className="filters" role="search">
        <input className="search" type="search" placeholder="Search by name, university or field…" aria-label="Search scholarships" value={q} onChange={(e) => setQ(e.target.value)} />
        <select aria-label="University" value={uni} onChange={(e) => setUni(e.target.value)}>
          <option value="">All universities</option>
          {unis.map((u) => <option key={u}>{u}</option>)}
        </select>
        <select aria-label="Study level" value={level} onChange={(e) => setLevel(e.target.value)}>
          <option value="">All levels</option>
          <option>PhD / Research</option>
          <option>Master by Coursework</option>
          <option>Undergraduate</option>
        </select>
        <select aria-label="Who can apply" value={who} onChange={(e) => setWho(e.target.value)}>
          <option value="">Domestic &amp; international</option>
          <option value="intl">Open to international</option>
          <option value="dom">Domestic only</option>
        </select>
        <select aria-label="Status" value={st} onChange={(e) => setSt(e.target.value)}>
          <option value="">Any status</option>
          <option value="open">Open now</option>
          <option value="upcoming">Opening soon</option>
          <option value="closed">Recently closed</option>
        </select>
      </div>
      <p className="count">Showing {rows.length} of {list.length} scholarships</p>
      <div className="grid">
        {rows.length === 0 && <div className="empty">No scholarships match these filters. Try widening your search.</div>}
        {rows.map((x) => {
          const s = status(x);
          const cls = s.k === "open" ? (s.soon ? "b-soon" : "b-open") : s.k === "upcoming" ? "b-upcoming" : "b-closed";
          const whoLabel = x.who === "dom" ? "Domestic only" : x.who === "intl" ? "International students" : "Domestic & international";
          return (
            <article className="card" key={x.uni + x.name}>
              <div className="card-top">
                <div>
                  <div className="uni">{x.uni}</div>
                  <h3>{x.name}</h3>
                </div>
                <span className={`badge ${cls}`}>{s.label}</span>
              </div>
              <div className="value">{x.value}</div>
              <div className="tags">
                {[x.level, x.level2].filter(Boolean).map((l) => <span className="tag" key={l}>{l}</span>)}
                <span className="tag">{whoLabel}</span>
                <span className="tag">{x.field}</span>
              </div>
              <p className="meta"><b>Closes:</b> {fmtDate(x.closes)}</p>
              <p className="note">{x.note}</p>
              <a className="apply" href={x.url} target="_blank" rel="noopener" data-scholarship={`${x.uni} – ${x.name}`}>
                View official page ↗
              </a>
            </article>
          );
        })}
      </div>
    </>
  );
}

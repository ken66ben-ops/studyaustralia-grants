"use client";
import { useEffect } from "react";

export default function ThemeToggle() {
  useEffect(() => {
    try {
      const t = localStorage.getItem("sag-theme");
      if (t) document.documentElement.setAttribute("data-theme", t);
    } catch {}
  }, []);

  function toggle() {
    const root = document.documentElement;
    const cur = root.getAttribute("data-theme") || (matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light");
    const next = cur === "dark" ? "light" : "dark";
    root.setAttribute("data-theme", next);
    try { localStorage.setItem("sag-theme", next); } catch {}
  }

  return (
    <button className="theme-btn" type="button" onClick={toggle} aria-label="Toggle colour theme">
      Theme
    </button>
  );
}

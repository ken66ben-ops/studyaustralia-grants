"use client";
import { useEffect } from "react";
import { usePathname } from "next/navigation";

// Anonymous visit and click counting. Sends no names, emails or IP addresses.
function send(payload) {
  const body = JSON.stringify(payload);
  try {
    if (navigator.sendBeacon) navigator.sendBeacon("/api/track", new Blob([body], { type: "application/json" }));
    else fetch("/api/track", { method: "POST", body, headers: { "content-type": "application/json" }, keepalive: true });
  } catch {}
}

export default function Tracker() {
  const path = usePathname();

  useEffect(() => {
    if (path.startsWith("/admin")) return;
    send({ type: "view", path, referrer: document.referrer || "" });
  }, [path]);

  useEffect(() => {
    function onClick(e) {
      const a = e.target.closest && e.target.closest("a[data-scholarship]");
      if (a) send({ type: "click", path: location.pathname, scholarship: a.dataset.scholarship });
    }
    document.addEventListener("click", onClick);
    return () => document.removeEventListener("click", onClick);
  }, []);

  return null;
}

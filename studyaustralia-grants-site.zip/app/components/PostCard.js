import Link from "next/link";
import { fmtPostDate } from "@/lib/posts";

export default function PostCard({ p }) {
  const excerpt = p.body.length > 160 ? p.body.slice(0, 160).trimEnd() + "…" : p.body;
  return (
    <Link className="post" href={`/news/${p.id}`}>
      {p.image_url && <img src={p.image_url} alt="" loading="lazy" />}
      <div className="pb">
        <time dateTime={p.created_at}>{fmtPostDate(p.created_at)}</time>
        <h3>{p.title}</h3>
        <p className="muted" style={{ margin: 0 }}>{excerpt}</p>
      </div>
    </Link>
  );
}

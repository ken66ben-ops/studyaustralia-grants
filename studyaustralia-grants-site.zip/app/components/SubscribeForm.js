"use client";
import { useState } from "react";
import Link from "next/link";

export default function SubscribeForm() {
  const [state, setState] = useState({ busy: false, ok: "", err: "" });

  async function submit(e) {
    e.preventDefault();
    const form = e.currentTarget;
    const data = Object.fromEntries(new FormData(form));
    data.consent = form.consent.checked;
    setState({ busy: true, ok: "", err: "" });
    try {
      const r = await fetch("/api/subscribe", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(data) });
      const j = await r.json();
      if (!r.ok) throw new Error(j.error || "Something went wrong");
      form.reset();
      setState({ busy: false, ok: "You're on the list. We'll email you when new scholarships open or deadlines get close.", err: "" });
    } catch (err) {
      setState({ busy: false, ok: "", err: err.message });
    }
  }

  return (
    <form className="form" onSubmit={submit}>
      <div className="row">
        <label>Full name<input name="name" required maxLength={120} autoComplete="name" /></label>
        <label>Email<input name="email" type="email" required maxLength={200} autoComplete="email" /></label>
      </div>
      <div className="row">
        <label>Country<input name="country" maxLength={80} autoComplete="country-name" placeholder="e.g. Nigeria" /></label>
        <label>Study level
          <select name="level" defaultValue="">
            <option value="">Choose…</option>
            <option>PhD / Research</option>
            <option>Master by Coursework</option>
            <option>Undergraduate</option>
          </select>
        </label>
      </div>
      <label>Field of study<input name="field" maxLength={120} placeholder="e.g. Public health, Engineering" /></label>
      <input className="hp" name="website" tabIndex={-1} autoComplete="off" aria-hidden="true" />
      <label className="check">
        <input type="checkbox" name="consent" required />
        <span>I agree that StudyAustralia Grants can store these details and email me scholarship alerts. I can unsubscribe at any time. <Link href="/privacy">Privacy</Link></span>
      </label>
      <div><button className="btn" disabled={state.busy}>{state.busy ? "Signing up…" : "Get deadline alerts"}</button></div>
      {state.ok && <p className="msg ok" role="status">{state.ok}</p>}
      {state.err && <p className="msg err" role="alert">{state.err}</p>}
    </form>
  );
}

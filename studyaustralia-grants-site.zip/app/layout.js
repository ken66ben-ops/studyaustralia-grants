import "./globals.css";
import Link from "next/link";
import Tracker from "./components/Tracker";
import ThemeToggle from "./components/ThemeToggle";

export const metadata = {
  title: "StudyAustralia Grants",
  description:
    "An independent guide to genuine, currently open scholarships at Edith Cowan University and other Australian universities, with links to every official application page.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
        <link
          href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,700&family=Inter:wght@400;500;600;700&display=swap"
          rel="stylesheet"
        />
      </head>
      <body>
        <nav className="nav" aria-label="Main">
          <div className="wrap">
            <Link className="logo" href="/" aria-label="StudyAustralia Grants home">
              <span className="mark" aria-hidden="true"></span>StudyAustralia Grants
            </Link>
            <ul>
              <li><Link href="/#scholarships">Scholarships</Link></li>
              <li><Link href="/news">News</Link></li>
              <li><Link href="/#alerts">Deadline alerts</Link></li>
              <li><Link href="/#how">How to apply</Link></li>
            </ul>
            <ThemeToggle />
          </div>
        </nav>
        {children}
        <footer>
          <div className="wrap">
            <p>
              <b>StudyAustralia Grants</b> is an independent information service. University names are used only to
              identify where each scholarship is offered; we are not endorsed by or affiliated with any institution listed.
            </p>
            <p>
              Information is a guide only and may change. Always confirm eligibility, values and deadlines on the official
              page before applying. <Link href="/privacy">Privacy</Link>
            </p>
          </div>
        </footer>
        <Tracker />
      </body>
    </html>
  );
}
